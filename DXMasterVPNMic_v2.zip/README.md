# DX MASTER - VPN Mic (Messenger Volume Booster)

UPLOAD (phone): Extract the zip, then on GitHub: Add file -> Upload files.
Select EVERYTHING inside the extracted folder (.github, app, build.gradle, settings.gradle,
gradle.properties, README.md) and Commit. Do not upload the zip itself.

BUILD: Actions tab -> "Build DX MASTER APK" -> wait 5-10 min -> download artifact DX-MASTER-APK.
